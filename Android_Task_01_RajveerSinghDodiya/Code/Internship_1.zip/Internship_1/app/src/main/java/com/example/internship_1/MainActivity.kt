package com.example.internship_1

import android.os.Bundle
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var mydata:ArrayList<MyModel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerview)
        mydata = ArrayList<MyModel>()

        mydata.add(MyModel("Amazon","Your delivery is on the way"))
        mydata.add(MyModel("Ind vs Aus","India batting order is getting stronger."))
        mydata.add(MyModel("Zomato","To get 40% discount press now"))
        mydata.add(MyModel("Youtube","Enable notification to get all updates"))

        recyclerView.adapter = MyAdapter(this,mydata)
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}