package com.example.internship_1

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(var context: Context,var data:ArrayList<MyModel>): RecyclerView.Adapter<MyAdapter.Demo>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Demo {
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.demo_layout, parent, false)
        return Demo(view)

    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: Demo, position: Int) {
        holder.title.text = data.get(position).title
        holder.descrip.text = data.get(position).descrip

    }

    class  Demo(view: View) :RecyclerView.ViewHolder(view) {
        val title:TextView = view.findViewById(R.id.txt_title)
        val descrip: TextView = view.findViewById(R.id.description)
    }


    }


