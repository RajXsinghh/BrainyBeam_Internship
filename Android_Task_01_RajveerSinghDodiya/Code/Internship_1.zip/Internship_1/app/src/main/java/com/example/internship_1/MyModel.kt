package com.example.internship_1

data class MyModel (
    var title:String?,
    var descrip:String?
)
