package com.example.internship__2;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Product> favoriteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<Product> productList = new ArrayList<>();
        favoriteList = new ArrayList<>();

        productList.add(new Product("1", "Bathing"));
        productList.add(new Product("2", "Meditation"));
        productList.add(new Product("3", "Breakfast"));
        productList.add(new Product("4", "Plan your day"));
        productList.add(new Product("5", "Take rest in between work"));

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ProductAdapter adapter = new ProductAdapter(productList, favoriteList);
        recyclerView.setAdapter(adapter);

        findViewById(R.id.btnFav).setOnClickListener(v -> {
            if (favoriteList.isEmpty()) {
                Toast.makeText(this, "No favorites added", Toast.LENGTH_SHORT).show();
                return;
            }

                Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
                intent.putParcelableArrayListExtra("favorites", new ArrayList<>(favoriteList));
                startActivity(intent);

        });
    }

}
