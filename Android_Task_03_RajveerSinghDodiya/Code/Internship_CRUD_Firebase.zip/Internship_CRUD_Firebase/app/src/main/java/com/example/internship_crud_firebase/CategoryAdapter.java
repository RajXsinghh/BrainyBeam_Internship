package com.example.internship_crud_firebase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.dynamic.OnDelegateCreatedListener;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> {

    private List<Category> categoryList;
    private OnDeleteClickListener onDeleteClickListener;  // Interface for delete callback

    public CategoryAdapter(List<Category> categoryList, OnDeleteClickListener onDeleteClickListener) {
        this.categoryList = categoryList ;
        this.onDeleteClickListener=onDeleteClickListener;

    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category,parent,false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
       Category category = categoryList.get(position);
       holder.titleTextView.setText(category.getName());
       holder.descriptionTextView.setText(category.getDescription());

       //Handle delete click
        holder.imageViewDelete.setOnClickListener(v -> {
            if (onDeleteClickListener != null) {
                onDeleteClickListener.onDelete(category);
            }
        });

    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    public static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, descriptionTextView;
        ImageView imageViewDelete;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.textViewTitle);
            imageViewDelete = itemView.findViewById(R.id.imageViewDelete);
            descriptionTextView = itemView.findViewById(R.id.textViewDescription);
        }
    }

    //interface for delete functionality
    public interface OnDeleteClickListener {
        void onDelete(Category category);
    }

}

