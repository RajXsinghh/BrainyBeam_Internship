package com.example.internship_crud_firebase;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class SeeCategoryActivity extends AppCompatActivity
{

    private RecyclerView recyclerView;
    private CategoryAdapter adapter;
    private List<Category> categoryList;
    private FirebaseFirestore firestore;

    @Override
    protected  void onCreate(Bundle savedInstanceSate) {
        super.onCreate(savedInstanceSate);
        setContentView(R.layout.activity_see_categories);

        recyclerView = findViewById(R.id.recyclerview);
        firestore = FirebaseFirestore.getInstance();

        categoryList = new ArrayList<>();
        adapter = new CategoryAdapter(categoryList, this::deleteCategory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        fetchCategories();
    }

        public void fetchCategories() {
        firestore.collection("Categories")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                   categoryList.clear();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {

                        // convert document to category object
                        Category category = document.toObject(Category.class);
                        categoryList.add(category);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to fetch categories", Toast.LENGTH_SHORT).show();

                });
    }

    private void deleteCategory(Category category) {
        firestore.collection("Categories")
                .document(category.getId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Category deleted", Toast.LENGTH_SHORT).show();
                    categoryList.remove(category);
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to delete category", Toast.LENGTH_SHORT).show();
                });
    }

}
