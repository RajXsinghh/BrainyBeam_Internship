package com.example.internship_database;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        EditText Name = findViewById(R.id.Name);
        EditText Email = findViewById(R.id.Email);
        EditText Phone = findViewById(R.id.Phone);
        EditText City = findViewById(R.id.City);
        EditText Occupation = findViewById(R.id.Occupation);
        EditText Hobbies = findViewById(R.id.Hobbies);
        Button button = findViewById(R.id.btnSave);

        Button viewUserButton = findViewById(R.id.btnViewUsers);

        viewUserButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UserListActivity.class);
            startActivity(intent);
        });



        button.setOnClickListener(v -> {
            new Thread(() -> {
                String name = Name.getText().toString();
                String email = Email.getText().toString();
                String phone = Phone.getText().toString();
                String city = City.getText().toString();
                String occupation = Occupation.getText().toString();
                String hobbies = Hobbies.getText().toString();

                if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || city.isEmpty() || occupation.isEmpty() || hobbies.isEmpty()) {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show()
                    );
                } else {
                    User user = new User(name, email, phone, city, occupation, hobbies);
                    UserDatabase.getInstance(this).userDao().insert(user);

                    runOnUiThread(() ->
                            Toast.makeText(this, "User details filled successfully", Toast.LENGTH_SHORT).show()
                    );
                }
            }).start();
        });

    } }
