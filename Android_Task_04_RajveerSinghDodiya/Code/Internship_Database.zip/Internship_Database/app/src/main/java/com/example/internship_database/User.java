    package com.example.internship_database;

    import androidx.room.Entity;
    import androidx.room.PrimaryKey;

    @Entity(tableName = "user_table")
    public class User {
        @PrimaryKey(autoGenerate = true)
        private int id ;

        private String name;
        private String email;
        private String phone;
        private String hobbies;
        private String city;
        private String occupation;

        public User(String name, String email, String phone, String hobbies, String city, String occupation){
            this.name=name;
            this.city=city;
            this.email=email;
            this.hobbies=hobbies;
            this.occupation=occupation;
            this.phone=phone;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getEmail() {
            return email;
        }

        public String getPhone() {
            return phone;
        }

        public String getCity() {
            return city;
        }

        public String getHobbies() {
            return hobbies;
        }

        public String getOccupation() {
            return occupation;
        }

        public void setName(String name) {
            this.name=name;
        }

        public void setEmail(String email) {
            this.email=email;
        }

        public void setPhone(String phone) {
            this.phone=phone;
        }

        public void setCity(String city) {
            this.city=city;
        }

        public void setHobbies(String hobbies) {
            this.hobbies=hobbies;
        }

        public void setOccupation(String occupation) {
            this.occupation = occupation;
        }

        public void setId(int id) {
            this.id = id;
        }
    }

