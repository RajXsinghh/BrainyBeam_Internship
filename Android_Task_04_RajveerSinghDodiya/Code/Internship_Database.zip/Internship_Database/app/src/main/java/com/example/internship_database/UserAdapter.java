package com.example.internship_database;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private final List<User> userList;

    public UserAdapter(List<User> userList) {
        this.userList=userList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main,parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
       User user = userList.get(position);
       holder.Name.setText(user.getName());
       holder.Email.setText(user.getEmail());
       holder.Phone.setText(user.getPhone());
       holder.City.setText(user.getCity());
       holder.Occupation.setText(user.getOccupation());
       holder.Hobbies.setText(user.getHobbies());
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    static class UserViewHolder extends RecyclerView.ViewHolder {
         TextView Name, Email, Phone, City, Occupation, Hobbies;

         public UserViewHolder (@NonNull View itemView) {
              super(itemView);
              Name = itemView.findViewById(R.id.Name);
              Email = itemView.findViewById(R.id.Email);
              Phone = itemView.findViewById(R.id.Phone);
              City = itemView.findViewById(R.id.City);
              Occupation = itemView.findViewById(R.id.Occupation);
              Hobbies = itemView.findViewById(R.id.Hobbies);
         }

         }

    }

