package com.example.internship_database;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.concurrent.Executors;

public class UserListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // use a background thread to fetch data from the database
        Executors.newSingleThreadExecutor().execute(() -> {
            UserDatabase database = UserDatabase.getInstance(this);
            List<User> userList = database.userDao().getAllUsers();

            // update recyclerview adapter on the main thread
            runOnUiThread(() -> {
                if(userList.isEmpty()) {
                    //toast messaGE IF NO DATA AVAILABLE
                    Toast.makeText(this, "NO data available to display", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else{
                UserAdapter adapter = new UserAdapter(userList);
                recyclerView.setAdapter(adapter); }
            });
        });




    }


}
