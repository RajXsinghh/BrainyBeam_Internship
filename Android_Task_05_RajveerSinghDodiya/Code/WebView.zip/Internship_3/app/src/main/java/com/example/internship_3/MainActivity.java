package com.example.internship_3;

import android.annotation.SuppressLint;
import androidx.activity.OnBackPressedCallback;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private List<String> browseHistory;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize WebView and buttons
        webView = findViewById(R.id.webView);

        Button btnClearHistory = findViewById(R.id.btnClearHistory);
        Button btnBack = findViewById(R.id.btnBack);

        // Initialize browsing history
        browseHistory = new ArrayList<>();

        // Setup WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Save the URL to the history after the page finishes loading
                if (browseHistory.isEmpty() || !browseHistory.get(browseHistory.size() - 1).equals(url)) {
                    browseHistory.add(url);
                }
            }
        });

        // Load the initial webpage
        webView.loadUrl("https://www.google.com");

        // Clear History Button
        btnClearHistory.setOnClickListener(v -> {
            if (!browseHistory.isEmpty()) {
                browseHistory.clear();
                Toast.makeText(MainActivity.this, "History Cleared", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "No history to clear.", Toast.LENGTH_SHORT).show();
            }
        });

        // Back Button
        btnBack.setOnClickListener(v -> {
            if (browseHistory.size() > 1) {
                // Remove the current page and load the previous one
                browseHistory.remove(browseHistory.size() - 1);
                String previousUrl = browseHistory.get(browseHistory.size() - 1);
                webView.loadUrl(previousUrl);
            } else {
                Toast.makeText(MainActivity.this, "No more history to go back.", Toast.LENGTH_SHORT).show();
            }
        });


    // Handle back press for WebView navigation

   getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            if (webView.canGoBack()) {
                webView.goBack();
            }

            else {
                finish();
            }
        }

    });
}
}

